class User:
    #User creation
    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.account_balance = 0
    
    #method creation
    def make_deposit(self, amount):
        self.account_balance+= amount
    #method creation
    def make_transfer(self, user2, amount):
        self.account_balance-=amount
        user2.account_balance+=amount
    #method creation    
    def make_withdrawal(self, amount):
        self.account_balance-=amount

John = User("John Cleese", "john@montypython.com")
Graham = User("Graham Chapman", "Graham@montypython.com")
Sir = User("Sir Lance-A-Lot", "sirlancealot@montypython.com")

John.make_deposit(10000)
print(John.account_balance)

John.make_transfer(Sir, 1)
print(John.account_balance)
John.make_withdrawal(1111)

print(John.account_balance)
print(Sir.account_balance)
